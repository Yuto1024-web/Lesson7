class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_one_attached :profile_image
  has_many :books, dependent: :destroy

  # ここから追加
  validates :name,
            presence: true,
            length: { minimum: 2, maximum: 20 },
            uniqueness: { case_sensitive: false }

  validates :introduction,
            length: { maximum: 50 }
end