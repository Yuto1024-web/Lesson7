class UsersController < ApplicationController
  before_action :authenticate_user!
  before_action :set_user, only: [:show, :edit, :update]
  before_action :authorize_user!, only: [:edit, :update]

  def index
    @users = User.all                     # 一覧用
    @user  = current_user                 # 左側User info表示用
    @book  = Book.new
  end

  def show
    @user = User.find(params[:id])        # 表示対象ユーザー
    @book = Book.new                      # 右側投稿フォーム（Book new用）
    @books = @user.books.order(created_at: :desc)  # そのユーザーの投稿一覧
  end

  def edit; end

  def update
    if @user.update(user_params)
      redirect_to @user, notice: "User information was successfully updated."
    else
      flash.now[:alert] = "Failed to update user information."
      render :edit, status: :unprocessable_entity
    end
  end

  private

  def set_user
    @user = User.find(params[:id])
  end

  def authorize_user!
    return if @user == current_user
    redirect_to user_path(current_user), alert: "Not authorized."
  end


  # ★ ここだけにまとめる（introduction を必ず許可）
  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image, :email)
  end
end