class BooksController < ApplicationController
  before_action :authenticate_user!  

  before_action :set_book, only: [:show, :edit, :update, :destroy]
  before_action :authorize_owner!, only: [:edit, :update, :destroy]

  def index
    @books = Book.includes(:user).order(created_at: :desc)
    @book  = Book.new          # ← サイドバーの新規投稿フォーム用（変数名は @book が鉄板）
    @user  = current_user      # ← サイドバーのプロフィール表示用
  end

  def show
    @new_book = Book.new          # サイドバーの新規投稿フォーム用
    @user     = @book.user        # ★ ここを変更：投稿者の情報をサイドバーに表示
  end

  def create
    @book = current_user.books.new(book_params)             # ← user_id 自動セットOK
    if @book.save
      redirect_to @book, notice: "Book was successfully created."
    else
      # フォームが index にある場合は index を再描画する
      @books = Book.includes(:user).order(created_at: :desc)
      flash.now[:alert] = "Failed to create the book."
      render :index, status: :unprocessable_entity
    end
  end

  def edit; end

  def update
    if @book.update(book_params)
      redirect_to @book, notice: "Book was successfully updated."
    else
      flash.now[:alert] = "Failed to update the book."
      render :edit, status: :unprocessable_entity
    end
  end
  
  def destroy
    @book.destroy
    redirect_to books_path, notice: "Book was successfully deleted."
  end

  private
  def set_book
    @book = Book.find(params[:id])
  end

  def authorize_owner!
    redirect_to books_path, alert: "Not authorized." unless @book.user_id == current_user.id
  end

  def book_params
    params.require(:book).permit(:title, :body)
  end
end